package com.example.pokemon;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class Pokeadvice extends AppCompatActivity {
      private ImageView Image = findViewById(R.id.image);
      private TextView name = findViewById(R.id.Name);
      private TextView T = findViewById(R.id.Total);
      private TextView atk = findViewById(R.id.Attack);
      private TextView def = findViewById(R.id.Def);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pokeadvice);
        Bundle PokeLand = new Bundle();
        String Name = PokeLand.getBundle("Name").toString();
        String Total = PokeLand.getBundle("Total").toString();
        String img = PokeLand.getBundle("Image").toString();
        int Img = Integer.parseInt(img);
        String Attack = PokeLand.getBundle("Attack").toString();
        String Defence = PokeLand.getBundle("Def").toString();

        Image.setImageResource(Img);
        name.setText("Name: " + Name);
        T.setText("Total: " + Total);
        atk.setText("Attack: " + Attack);
        def.setText("Defence: " + Defence);


    }
}